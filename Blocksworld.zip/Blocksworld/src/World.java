import java.util.Arrays;

public class World {
    private int width, height, cells;
    private int[][] grid;
    int agentX, agentY;

    public World(int x, int y){
        width = x;
        height = y;
        cells = height*width;
        grid = new int[height][width];

        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                grid[i][j] = -1; //-1 denotes an empty space
            }
        }
        init();
    }

    public void init(){
        agentX = width - 1;
        agentY = height - 1;
        grid[agentY][agentX] = 0; //agent is marked as 0

        for(int i = 0; i < height - 1 && i < width - 1; i++){
            grid[height - 1][i] = i + 1; //box a is marked as 1, b as 2, etc
        }

        for(int i = 0; i < height; i++){
            System.out.println(Arrays.toString(grid[i]));
        }
    }

    public void generateSolution(){

    }

    public Boolean testSolution(){
        return false;
    }

    public Boolean moveLeft(){
        return null;
    }
    public Boolean moveRight(){
        return null;
    }
    public Boolean moveUp(){
        return null;
    }
    public Boolean moveDown(){
        return null;
    }
}
